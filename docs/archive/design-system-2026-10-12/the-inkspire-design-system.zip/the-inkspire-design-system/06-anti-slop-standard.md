# Anti-slop standard

These are hard constraints. They apply to every screen, component and token, and a screen that breaks one does not ship.

## Grounding

| ID | Rule |
| --- | --- |
| G1 | Every visual decision has a recorded reason, taken from Lorcana's world (the inks, ink and lore, exert and ready, the 63 × 88 mm card, the table) or from a function. "It looks nice" and "it is common" are not reasons. |
| G2 | Our identity is our own. The official Disney Lorcana brand language (gilt hairline frames with diamond ornaments, condensed capitals, page-turn motifs, the Lorcana wordmark) is never our identity. |
| G3 | Cards and card data lead, and chrome is quiet. Official art is shown as the card it is. Every surface also works with a neutral rendition of identical layout. |

## Composition and information design

| ID | Rule |
| --- | --- |
| C1 | Layouts follow the content and the task. Never use the centred-hero-plus-three-cards skeleton, and never use a KPI tile grid as identity. Home shows the next useful action, recent progress and the table world. |
| C2 | Hierarchy comes from scale contrast, weight and spacing first. Borders, fills, radius and shadow mark a separate object only where it really is one. |
| C3 | Domain information design is the measure of professionalism. Restate queries in plain language, explain legality with the rule, show ink identity in every row that needs it, and use real units (cost, 20 lore, 60 cards, 4 copies, 2 inks). |
| C4 | The crowded real board and the practical deckbuilder are the reference screens. An empty, beautiful table proves nothing. |

## Type, colour and shape

| ID | Rule |
| --- | --- |
| T1 | Every typeface is chosen for a stated reason and set to a declared scale with real contrast between steps. |
| T2 | Colour comes from meaning. The six inks are semantic, never decoration. One dominant field with a sharp accent beats an evenly spread palette. Neutrals are true ink and paper, and the little tint they carry is deliberate. Colour never carries meaning alone. |
| T3 | One signature shape language, flowing ink, appears consistently in controls, frames and the table. |
| T4 | No unexplained gradients, glows, glass or sparkles. A gradient is allowed only when it encodes something, such as a deck's two inks. |

## Motion and feel

| ID | Rule |
| --- | --- |
| M1 | Game events get authored feedback. Repeated interface actions get near-instant response. Interface transitions stay under about 300 ms with ease-out or springs, and every animation yields to new input. |
| M2 | Animation presents committed results only. Reduced motion reaches the same final state. |
| M3 | One orchestrated moment beats scattered effects. Cosmetic table interactions never touch game state or another player's view. |

## Interaction, content and access

| ID | Rule |
| --- | --- |
| I1 | Feedback arrives within 100 ms. Destructive actions commit on release or after confirmation, and reversible actions are cheap. Targets respect Fitts's law and the 44 px preference, and nothing shifts under the pointer. |
| I2 | Every screen designs its empty, loading, error, offline and stale states. |
| I3 | Copy is specific and uses the official rules vocabulary. No marketing clichés, no emoji, no weightless headlines. |
| I4 | Domain glyphs (official ink symbols, authored game glyphs) come before generic icons. One utility icon family is used, and only where an icon adds meaning. |
| I5 | WCAG 2.2 AA is the floor, plus a 7:1 high-contrast mode, text scaling, contrast measured over art, colour plus shape everywhere and a complete semantic board. |

## Process and enforcement

| ID | Rule |
| --- | --- |
| P1 | References are studied for what makes them work and never copied. Every direction and screen review uses the same dense fixture board, deckbuilder and pack sequence. |
| P2 | Hierarchy is settled in greyscale before colour. Every view is stress-tested before implementation: a crowded board, the longest names, all six inks, phone width, high contrast and reduced motion. |
| P3 | Tooling enforces the rules: tokens are the only source of values, lint rejects raw values, contrast is checked in CI, Storybook carries a state matrix for every component, and every screen review runs the four-question audit. |
| P4 | The Director signs off direction and creative acceptance. A second reviewer checks each screen against this standard. |

## Never ship

| Area | Never |
| --- | --- |
| Palette | An indigo or purple accent by default. A purple-to-blue gradient hero. A timid, evenly spread palette. Neon glow on dark. Pure mid-greys. |
| Type | A typeface used because it was the default. Hierarchy made only of bigger text. Small size steps and timid weight contrast. |
| Layout | A centred hero, then three feature cards, then a call to action. Everything centred. Bento grids by reflex. KPI tile rows as a home page. |
| Shape and surface | The same radius and soft shadow on every block. Pill buttons everywhere. Glassmorphism. Rounded cards with a coloured side rail. |
| Iconography | Thin line icons that could illustrate any product. An icon on every nav item. Emoji as section markers. Sparkle glyphs for magic. |
| Copy | Weightless headlines. "Unlock the power of". Em-dash asides. Colon-reveal sentences. Invented labels in quotes. |
| Motion | Fade-ups on scroll everywhere. A hover lift on everything. Animation on high-frequency actions. |
| Robustness | A missing empty, error, loading or offline state. No validation. A missing focus state. Text that overflows. |

## The defaults move

Replacing one default with the next is not a fix. These are today's defaults and are equally out:

- a warm cream ground with a fashionable serif display and a sage or forest-green accent
- near-black with a single acid-green or vermilion accent
- broadsheet hairline rules
- accent rails on rounded cards

A choice is deliberate only when its reason comes from The Inkspire.

## The Director's never list

- A generic dashboard.
- Anything childish or toy-like.
- The dark neon gamer look.
- Overloaded effects.

## Four-question audit

Ask these of every screen:

1. Was each typeface chosen for a stated reason, or inherited?
2. Is each colour derived from meaning, or the median?
3. Does the layout follow the content, or a template?
4. Does the copy say something only The Inkspire would say?
