# Platform

| Layer | Built with | Renders |
| --- | --- | --- |
| Interface | React 19.3, Vite 8.3, React Aria Components 1.21.1, CSS Modules | Every room, menu, panel and form, on accessible primitives |
| Table | Babylon.js 9.29 | The 2.5D tactile board, its depth, lighting and card motion |
| Premium finishes | CardFX (WebGL2) | Foil, Enchanted and special-rarity finishes |

## Rules

- Tokens are the only source of values. Components never contain raw colours, sizes or durations.
- Every component has a Storybook state matrix.
- Every screen designs its empty, loading, error, offline and stale states.
