# Cards and table

## The table

- **Presentation.** A 2.5D tactile board. Mostly flat and highly readable, with real depth, lighting and physical card motion.
- **Pacing.** Deliberate. The player has room to read and savour, and the table never rushes. Every input still responds instantly.
- **Card motion.** Weighty and physical. Cards slide, settle and land like real card stock.
- **Readability.** The table is calm and readable most of the time. The crowded real board is the reference, not an empty one.

## Big moments

Spectacle is reserved for these moments, and only these:

- big character plays (high cost, Shift)
- songs and major actions
- banishing in challenges
- the winning quest (20 lore, match end)
- pack reveals

One orchestrated moment beats scattered effects. Every effect yields to new input, and reduced motion reaches the same final state.

## Premium finishes

Foil, Enchanted and special rarities get animated premium finishes: moving foil light, shimmer and depth.

**CardFX** renders them. It is The Inkspire's WebGL2 foil renderer and is used in its current form.

- It layers each printing's foil mask, etched top layers and hot-foil colours so a finish behaves like the physical card.
- It responds to pointer, ambient and showcase motion.
- It honours reduced motion.
- It falls back to the flat card if the graphics context is lost.

## Card Inspector

- Card text set live in the inspector uses faces that match the printed card's typography as closely as possible, so the inspected card reads like the physical card.
- Card-face faces are used for card content only, never for interface text.

## Pack opening

- **Default.** A ceremonial reveal, one card at a time, building to the rarest.
- **Always available.** Skip, one at a time, and bulk.
- A pack reveal is one of the big moments.
