The Inkspire is a free Disney Lorcana game on the web for Illumineers: play at the table, open packs, keep a collection and build decks, all in one world. This system holds every design decision made for it and the standard every screen is held to. Read it before you design or build any surface. Every rule here is binding.

## Principles

1. **Lorcana-native, in our own style.** Take every choice from Lorcana's world (the inks, lore, the Illumineer's craft, the card itself) or from a function. The official Disney Lorcana brand language is never our identity.
2. **Ink, paper and light.** The world is an abstract ink realm. Every surface is made of ink, paper or light, with no literal room or furniture.
3. **A calm table, with magic that is earned.** The table stays calm and readable. Spectacle erupts only on the big moments listed in Cards and table.
4. **Instant response, unhurried play.** Every input answers at once. The flow of play never rushes the player.
5. **The card leads.** Chrome stays quiet so the cards, their art and their finishes carry the experience.
6. **One world, many rooms.** One identity runs through every area, and each room is tuned to its people: the Lab to competitors, the Collection to collectors, Learn to newcomers.
7. **Phone equals desktop.** Every journey is designed for phone from the start.

## Content fundamentals

- Use the official rules vocabulary: ink, inkwell, exert, ready, quest, challenge, banish, lore, Shift, Song.
- Use real units: cost, 20 lore, 60 cards, 4 copies, 2 inks.
- Say something only this game would say. No marketing clichés, no weightless headlines, no emoji.
- Explain legality with the rule that applies.
- The product has no persona. It never speaks as a character and never casts the player in a role.

## Visual foundations

- **Colour.** Neutrals are true ink on paper: a deep ink-dark and a clean paper-light with very little tint. The interface stays neutral. The six ink colours appear only as accents, in symbols, chips, deck bars and effects. Colour comes from meaning and never carries meaning alone.
- **Themes.** Paper (light) and Ink (dark) are equal and first-class. Follow the system setting until the player changes it in settings.
- **Type.** Set interface text in a crisp, precise contemporary sans. Reserve one characterful display face for moments. In the Card Inspector, set live card text in faces that match the printed card as closely as possible, and use those faces only for card content.
- **Shape.** Flowing ink: organic, brushed edges and pooling forms, soft and always in motion. Use it consistently in controls, frames and the table.
- **Density.** Visual first. The deckbuilder and the collection open on large card-art grids, with a dense list one click away. Charts and statistics are instrument-precise everywhere.
- **Motion.** Cards move with weight: they slide, settle and land like real card stock. Interface responses are near-instant, and authored effects belong to game events.
- **Premium finishes.** Foil, Enchanted and special rarities get animated finishes (moving foil light, shimmer and depth), rendered by CardFX.
- **Sound.** Sound supports play: cues for key events and optional ambience. The game reads fully without sound.

## Iconography

- Domain glyphs come first: the official ink symbols and authored game glyphs.
- Use one utility icon family, and only where an icon adds meaning.
- Never put an icon on every nav item, a sparkle glyph on anything magic, or an emoji anywhere.

## Review

Run this four-question audit on every screen before it ships:

1. Was each typeface chosen for a stated reason, or inherited?
2. Is each colour derived from meaning, or the median?
3. Does the layout follow the content, or a template?
4. Does the copy say something only The Inkspire would say?

A screen that fails any question goes back. The full set of constraints is in Anti-slop standard.
