# Accessibility and language

## The floor

WCAG 2.2 AA is the minimum. On top of it, every surface provides:

- a 7:1 high-contrast mode
- text scaling
- contrast measured over card art, not only over flat surfaces
- colour plus shape everywhere, so colour never carries meaning alone
- a complete semantic board

## Entry and preferences

- Accessibility lives in settings. There is no first-launch accessibility prompt.
- System preferences for reduced motion, contrast and light or dark are followed silently by default until the player changes them in settings.

## Features

- Scalable UI.
- Phone, tablet and desktop layouts.
- Colour-blind support.
- High contrast.
- Screen-reader support.
- Keyboard navigation.
- Reduced animation and reduced motion.
- Large-card preview.

## Interaction

- Targets respect Fitts's law, with a preferred touch target of 44 CSS px.
- Nothing shifts under the pointer.
- Destructive actions commit on release or after confirmation. Reversible actions are cheap.

## Text

- Body text stays between 15 and 25 px, with 120–145% line height and 45–90 characters per line.
- All caps get 5–12% letter-spacing.
- Figures that line up use tabular numerals.

## Languages

- English, French, German, Italian and Spanish.
- Every typeface covers the full character set of all five.
