# Identity

| Decision | What it means |
| --- | --- |
| **Name** | The Inkspire. Slug: `the-inkspire`. |
| **Identity** | Deeply Lorcana-native, in an original style of our own. Official Disney Lorcana branding is never used as The Inkspire's identity. |
| **Lead motif** | The Illumineer's craft: the Illumineer's tools, lorebooks, the Great Illuminary and the act of summoning with ink. The motif is expressed through ink, paper and light, never through a worktable or props. |
| **Setting** | An abstract ink realm. Surfaces of ink, paper and light, stylised rather than a physical room, with no literal furniture. |
| **Persona** | None. The craft motif shapes the look. The player is not given a role, a character or an avatar identity. |
| **Table feel** | Magical spectacle: expressive ink and light, Lorcana's magic made visible, placed only on the big moments. |
| **Shape language** | Flowing ink: organic, brushed edges and pooling forms, with softness and movement. |
| **Quality bar** | Speed and snappiness in every interaction, big-moment effects with real impact, and card finishes and variants at a premium level. |

## Never

- A generic dashboard.
- Anything childish or toy-like.
- The dark neon gamer look.
- Overloaded effects.
