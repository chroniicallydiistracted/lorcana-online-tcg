# Official assets and notice

The Inkspire uses Disney Lorcana assets in full under the Director's decision D07: card art and images, card text, names, set symbols, ink symbols and products.

## Rules

- **Free, always.** Nobody is ever charged to use or access any content. That means no paid tiers, paid cosmetics, paid tournament entry or donation-unlocked perks.
- **Shown as what they are.** Official assets appear as cards, ink symbols, set symbols and products. Official logos are never used as The Inkspire's branding.
- **Provenance.** Every imported asset records its source system or URL, retrieval date, checksum, dimensions and format, rendition family, and the rights basis `D07: Ravensburger fan-content terms`.
- **Neutral renditions.** Every surface that shows official art also works with neutral placeholders of identical layout. One configuration switch swaps between them.

## The notice

The notice appears word for word:

> The Inkspire uses trademarks and/or copyrights associated with Disney Lorcana TCG, used under Ravensburger’s Community Code Policy (https://cdn.ravensburger.com/lorcana/community-code-en). We are expressly prohibited from charging you to use or access this content. The Inkspire is not published, endorsed, or specifically approved by Disney or Ravensburger. For more information about Disney Lorcana TCG, visit https://www.disneylorcana.com/en-US/.

It appears in each of these places:

| Surface | Placement |
| --- | --- |
| Web app | A footer or About and legal page reachable from every screen, plus the start and loading screen. |
| Repository | `README.md`. |
| Published media | Every published piece of artwork, video, screenshot post and listing. |
