# Motion and sound

## Speed and pace

- **Instant response to every input.** Feedback arrives within 100 ms.
- **Unhurried flow of play.** Play leaves time to read.
- Interface transitions stay under about 300 ms, using ease-out or springs.
- Every animation yields to new input.

## Where motion belongs

- Game events get authored feedback.
- Repeated interface actions get near-instant response, with no animation.
- Spectacle is reserved for the big moments in Cards and table.
- Animation presents committed results only.
- Cosmetic table interactions are allowed where they never touch game state or another player's view.

## Card motion

Cards are weighty and physical. They slide, settle and land like real card stock.

## Reduced motion

Reduced motion follows the system setting silently until the player changes it in settings. It always reaches the same final state as full motion.

## Sound

- Sound supports play: cues for key events, plus optional ambience.
- The game reads fully without sound.
