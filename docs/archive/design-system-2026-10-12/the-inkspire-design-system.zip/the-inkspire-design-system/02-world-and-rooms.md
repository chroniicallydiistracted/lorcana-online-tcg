# World and rooms

The Inkspire is one world made of rooms. The identity is the same everywhere; each area (home, the table, Collection, Lab and Learn) has its own atmosphere and materials, all drawn from ink, paper and light.

## Who each room serves

When the needs of different players conflict, each area serves its own people.

| Room | Serves | Character |
| --- | --- | --- |
| **Home** | Every player | A personal space with no character. Collection, decks, progress and play are one step away. Styled with the craft motif, with no role-play or avatar identity. |
| **Collection** | Collectors | Binder pages: set-by-set pages with slots, where empty slots show what is missing. |
| **Lab** | Competitors | A precision instrument: calm, exact and information-rich. The most tool-like room. |
| **Learn** | Newcomers | Hands-on at the table: short guided scenarios and puzzles played on the real table. |
| **Table** | Players in a match | A calm, readable 2.5D board that erupts with magic on big moments. See Cards and table. |

## Journeys

- **First visit.** The player is free to explore and lands in home. Learning is offered and never required.
- **Phone.** Phone is equal to desktop. Every journey is designed for phone from the start, alongside tablet and desktop.
- **Deckbuilder and collection.** Visual first: large card-art grids by default, with a dense list mode one click away.
- **Charts and statistics.** Instrument-precise everywhere, in the style of the Lab, never illustrative.

## Social

- **At the core.** Friends, presence and profiles are prominent, including in home.
- **Spectating.** Spectator, caster and stream-overlay views are first-class and designed alongside the player table.
- **Reactions in a match.** Expressive, animated and characterful reactions are part of the spectacle. They are controlled emotes, never free chat, and block and mute always apply.

## Notifications

- Live toasts appear as things happen and are collected in an inbox afterwards.
- During a match, notifications are held until the match ends. A quiet count may show. Nothing interrupts play.

## Cosmetics

- Playmats, card backs, lore counters, profile frames and reaction sets are a major part of identity and progression.
- Every cosmetic is earned through play and never sold.
- A cosmetic skin may restyle materials. It never changes readability or accessibility tokens.

## Priority surfaces

- Packs and collection.
- Home and social.
- The reference screens every direction is judged on: a crowded real board, the deckbuilder and the pack sequence.
